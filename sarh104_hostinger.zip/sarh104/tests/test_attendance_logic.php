<?php
/**
 * ╔══════════════════════════════════════════════════════════════════════════════╗
 * ║           SARH SYSTEM - ATTENDANCE LOGIC TEST                                ║
 * ║           اختبار منطق تسجيل الحضور والانصراف                                  ║
 * ╠══════════════════════════════════════════════════════════════════════════════╣
 * ║  Run: php tests/test_attendance_logic.php                                    ║
 * ╚══════════════════════════════════════════════════════════════════════════════╝
 */

echo "═══════════════════════════════════════════════════════════════════════════════\n";
echo "                    اختبار منطق الحضور والانصراف                              \n";
echo "                    Attendance Check-in/Check-out Logic Test                   \n";
echo "═══════════════════════════════════════════════════════════════════════════════\n\n";

// ═══════════════════════════════════════════════════════════════════════════════
// TEST 1: Haversine Distance Calculation
// ═══════════════════════════════════════════════════════════════════════════════

echo "📍 TEST 1: Haversine Distance Calculation\n";
echo "─────────────────────────────────────────────\n";

/**
 * Haversine distance calculation (same as in action.php)
 */
function haversineDistance($lat1, $lon1, $lat2, $lon2) {
    $R = 6371000; // Earth's radius in meters
    
    $φ1 = deg2rad($lat1);
    $φ2 = deg2rad($lat2);
    $Δφ = deg2rad($lat2 - $lat1);
    $Δλ = deg2rad($lon2 - $lon1);
    
    $a = sin($Δφ / 2) * sin($Δφ / 2) +
         cos($φ1) * cos($φ2) *
         sin($Δλ / 2) * sin($Δλ / 2);
    
    $c = 2 * atan2(sqrt($a), sqrt(1 - $a));
    
    return $R * $c;
}

// Test cases for distance
$testCases = [
    // Same location
    [
        'name' => 'نفس الموقع (0 متر)',
        'lat1' => 24.7136, 'lon1' => 46.6753,
        'lat2' => 24.7136, 'lon2' => 46.6753,
        'expected' => 0,
        'tolerance' => 0.1
    ],
    // ~100m apart
    [
        'name' => 'مسافة 100 متر تقريباً',
        'lat1' => 24.7136, 'lon1' => 46.6753,
        'lat2' => 24.7145, 'lon2' => 46.6753,
        'expected' => 100,
        'tolerance' => 10
    ],
    // ~1km apart
    [
        'name' => 'مسافة 1 كيلومتر تقريباً',
        'lat1' => 24.7136, 'lon1' => 46.6753,
        'lat2' => 24.7226, 'lon2' => 46.6753,
        'expected' => 1000,
        'tolerance' => 50
    ],
    // Different longitude (~1km)
    [
        'name' => 'مسافة 1 كم على خط الطول',
        'lat1' => 24.7136, 'lon1' => 46.6753,
        'lat2' => 24.7136, 'lon2' => 46.6863,
        'expected' => 1000,
        'tolerance' => 100
    ],
];

$passed = 0;
$failed = 0;

foreach ($testCases as $test) {
    $distance = haversineDistance($test['lat1'], $test['lon1'], $test['lat2'], $test['lon2']);
    $diff = abs($distance - $test['expected']);
    $status = $diff <= $test['tolerance'] ? '✅ PASS' : '❌ FAIL';
    
    if ($diff <= $test['tolerance']) {
        $passed++;
    } else {
        $failed++;
    }
    
    echo sprintf("  %s: %s\n", $status, $test['name']);
    echo sprintf("     المتوقع: ~%dm | الفعلي: %.2fm | الفرق: %.2fm\n\n", $test['expected'], $distance, $diff);
}

// ═══════════════════════════════════════════════════════════════════════════════
// TEST 2: Geofence Check Logic
// ═══════════════════════════════════════════════════════════════════════════════

echo "\n📍 TEST 2: Geofence Check Logic (20m max)\n";
echo "─────────────────────────────────────────────\n";

$MAX_DISTANCE_METERS = 20;

$geofenceTests = [
    [
        'name' => 'داخل النطاق (5 متر)',
        'user_lat' => 24.7136,
        'user_lon' => 46.6753,
        'branch_lat' => 24.71364,
        'branch_lon' => 46.6753,
        'should_pass' => true
    ],
    [
        'name' => 'على حدود النطاق (19 متر)',
        'user_lat' => 24.7136,
        'user_lon' => 46.6753,
        'branch_lat' => 24.71377,
        'branch_lon' => 46.6753,
        'should_pass' => true
    ],
    [
        'name' => 'خارج النطاق (50 متر)',
        'user_lat' => 24.7136,
        'user_lon' => 46.6753,
        'branch_lat' => 24.7141,
        'branch_lon' => 46.6753,
        'should_pass' => false
    ],
    [
        'name' => 'بعيد جداً (500 متر)',
        'user_lat' => 24.7136,
        'user_lon' => 46.6753,
        'branch_lat' => 24.7181,
        'branch_lon' => 46.6753,
        'should_pass' => false
    ],
];

foreach ($geofenceTests as $test) {
    $distance = haversineDistance(
        $test['user_lat'], $test['user_lon'],
        $test['branch_lat'], $test['branch_lon']
    );
    
    $tolerance = 5; // GPS accuracy tolerance
    $is_within = $distance <= ($MAX_DISTANCE_METERS + $tolerance);
    $expected = $test['should_pass'];
    $status = ($is_within === $expected) ? '✅ PASS' : '❌ FAIL';
    
    if ($is_within === $expected) {
        $passed++;
    } else {
        $failed++;
    }
    
    echo sprintf("  %s: %s\n", $status, $test['name']);
    echo sprintf("     المسافة: %.2fm | المسموح: %dm+%dm | النتيجة: %s\n\n",
        $distance, $MAX_DISTANCE_METERS, $tolerance, $is_within ? 'مسموح' : 'مرفوض');
}

// ═══════════════════════════════════════════════════════════════════════════════
// TEST 3: Late Penalty Calculation
// ═══════════════════════════════════════════════════════════════════════════════

echo "\n⏰ TEST 3: Late Penalty Calculation\n";
echo "─────────────────────────────────────────────\n";

$grace_period = 15; // دقائق
$late_penalty_rate = 0.5; // نقطة لكل دقيقة

$lateTests = [
    [
        'name' => 'حضور في الموعد (08:00)',
        'work_start' => '08:00',
        'check_in' => '08:00',
        'expected_late' => 0,
        'expected_penalty' => 0
    ],
    [
        'name' => 'حضور خلال فترة السماح (08:10)',
        'work_start' => '08:00',
        'check_in' => '08:10',
        'expected_late' => 10,
        'expected_penalty' => 0 // ضمن فترة السماح
    ],
    [
        'name' => 'حضور متأخر 30 دقيقة (08:30)',
        'work_start' => '08:00',
        'check_in' => '08:30',
        'expected_late' => 30,
        'expected_penalty' => (30 - $grace_period) * $late_penalty_rate // 7.5 نقاط
    ],
    [
        'name' => 'حضور مبكر (07:45)',
        'work_start' => '08:00',
        'check_in' => '07:45',
        'expected_late' => 0,
        'expected_penalty' => 0
    ],
    [
        'name' => 'تأخر ساعة كاملة (09:00)',
        'work_start' => '08:00',
        'check_in' => '09:00',
        'expected_late' => 60,
        'expected_penalty' => (60 - $grace_period) * $late_penalty_rate // 22.5 نقاط
    ],
];

foreach ($lateTests as $test) {
    $work_start = new DateTime('2026-01-30 ' . $test['work_start']);
    $check_in = new DateTime('2026-01-30 ' . $test['check_in']);
    
    $late_minutes = 0;
    $penalty_points = 0;
    
    if ($check_in > $work_start) {
        $late_minutes = intval(($check_in->getTimestamp() - $work_start->getTimestamp()) / 60);
        
        if ($late_minutes > $grace_period) {
            $penalty_minutes = $late_minutes - $grace_period;
            $penalty_points = round($penalty_minutes * $late_penalty_rate, 2);
        }
    }
    
    $late_ok = $late_minutes === $test['expected_late'];
    $penalty_ok = abs($penalty_points - $test['expected_penalty']) < 0.01;
    $status = ($late_ok && $penalty_ok) ? '✅ PASS' : '❌ FAIL';
    
    if ($late_ok && $penalty_ok) {
        $passed++;
    } else {
        $failed++;
    }
    
    echo sprintf("  %s: %s\n", $status, $test['name']);
    echo sprintf("     التأخير: %d دقيقة (متوقع: %d) | الخصم: %.2f نقاط (متوقع: %.2f)\n\n",
        $late_minutes, $test['expected_late'], $penalty_points, $test['expected_penalty']);
}

// ═══════════════════════════════════════════════════════════════════════════════
// TEST 4: Overtime Bonus Calculation
// ═══════════════════════════════════════════════════════════════════════════════

echo "\n🌟 TEST 4: Overtime Bonus Calculation\n";
echo "─────────────────────────────────────────────\n";

$overtime_bonus_rate = 0.3 / 60; // نقطة لكل دقيقة
$min_overtime = 15; // الحد الأدنى للعمل الإضافي

$overtimeTests = [
    [
        'name' => 'انصراف في الموعد (17:00)',
        'work_end' => '17:00',
        'check_out' => '17:00',
        'expected_overtime' => 0,
        'expected_bonus' => 0
    ],
    [
        'name' => 'انصراف بعد 10 دقائق (أقل من الحد الأدنى)',
        'work_end' => '17:00',
        'check_out' => '17:10',
        'expected_overtime' => 10,
        'expected_bonus' => 0 // أقل من الحد الأدنى
    ],
    [
        'name' => 'انصراف بعد 30 دقيقة إضافية',
        'work_end' => '17:00',
        'check_out' => '17:30',
        'expected_overtime' => 30,
        'expected_bonus' => round(30 * $overtime_bonus_rate, 2)
    ],
    [
        'name' => 'انصراف بعد ساعة إضافية',
        'work_end' => '17:00',
        'check_out' => '18:00',
        'expected_overtime' => 60,
        'expected_bonus' => round(60 * $overtime_bonus_rate, 2)
    ],
];

foreach ($overtimeTests as $test) {
    $work_end = new DateTime('2026-01-30 ' . $test['work_end']);
    $check_out = new DateTime('2026-01-30 ' . $test['check_out']);
    
    $overtime_minutes = 0;
    $bonus_points = 0;
    
    if ($check_out > $work_end) {
        $overtime_minutes = intval(($check_out->getTimestamp() - $work_end->getTimestamp()) / 60);
        
        if ($overtime_minutes >= $min_overtime) {
            $bonus_points = round($overtime_minutes * $overtime_bonus_rate, 2);
        }
    }
    
    $overtime_ok = $overtime_minutes === $test['expected_overtime'];
    $bonus_ok = abs($bonus_points - $test['expected_bonus']) < 0.01;
    $status = ($overtime_ok && $bonus_ok) ? '✅ PASS' : '❌ FAIL';
    
    if ($overtime_ok && $bonus_ok) {
        $passed++;
    } else {
        $failed++;
    }
    
    echo sprintf("  %s: %s\n", $status, $test['name']);
    echo sprintf("     العمل الإضافي: %d دقيقة (متوقع: %d) | المكافأة: %.2f نقاط (متوقع: %.2f)\n\n",
        $overtime_minutes, $test['expected_overtime'], $bonus_points, $test['expected_bonus']);
}

// ═══════════════════════════════════════════════════════════════════════════════
// TEST 5: Early Leave Penalty Calculation
// ═══════════════════════════════════════════════════════════════════════════════

echo "\n🚪 TEST 5: Early Leave Penalty Calculation\n";
echo "─────────────────────────────────────────────\n";

$early_leave_rate = 0.5; // نقطة لكل دقيقة

$earlyLeaveTests = [
    [
        'name' => 'انصراف في الموعد',
        'work_end' => '17:00',
        'check_out' => '17:00',
        'expected_early' => 0,
        'expected_penalty' => 0
    ],
    [
        'name' => 'انصراف قبل 30 دقيقة',
        'work_end' => '17:00',
        'check_out' => '16:30',
        'expected_early' => 30,
        'expected_penalty' => 30 * $early_leave_rate
    ],
    [
        'name' => 'انصراف قبل ساعة',
        'work_end' => '17:00',
        'check_out' => '16:00',
        'expected_early' => 60,
        'expected_penalty' => 60 * $early_leave_rate
    ],
];

foreach ($earlyLeaveTests as $test) {
    $work_end = new DateTime('2026-01-30 ' . $test['work_end']);
    $check_out = new DateTime('2026-01-30 ' . $test['check_out']);
    
    $early_leave_minutes = 0;
    $penalty_points = 0;
    
    if ($check_out < $work_end) {
        $early_leave_minutes = intval(($work_end->getTimestamp() - $check_out->getTimestamp()) / 60);
        $penalty_points = round($early_leave_minutes * $early_leave_rate, 2);
    }
    
    $early_ok = $early_leave_minutes === $test['expected_early'];
    $penalty_ok = abs($penalty_points - $test['expected_penalty']) < 0.01;
    $status = ($early_ok && $penalty_ok) ? '✅ PASS' : '❌ FAIL';
    
    if ($early_ok && $penalty_ok) {
        $passed++;
    } else {
        $failed++;
    }
    
    echo sprintf("  %s: %s\n", $status, $test['name']);
    echo sprintf("     الخروج المبكر: %d دقيقة (متوقع: %d) | الخصم: %.2f نقاط (متوقع: %.2f)\n\n",
        $early_leave_minutes, $test['expected_early'], $penalty_points, $test['expected_penalty']);
}

// ═══════════════════════════════════════════════════════════════════════════════
// TEST 6: Working Days Check
// ═══════════════════════════════════════════════════════════════════════════════

echo "\n📅 TEST 6: Working Days Check\n";
echo "─────────────────────────────────────────────\n";

$workingDaysTests = [
    [
        'name' => 'يوم الأحد (0) - يوم عمل',
        'day' => 0,
        'working_days' => [0, 1, 2, 3, 4],
        'should_work' => true
    ],
    [
        'name' => 'يوم الجمعة (5) - إجازة',
        'day' => 5,
        'working_days' => [0, 1, 2, 3, 4],
        'should_work' => false
    ],
    [
        'name' => 'يوم السبت (6) - إجازة',
        'day' => 6,
        'working_days' => [0, 1, 2, 3, 4],
        'should_work' => false
    ],
    [
        'name' => 'يوم الجمعة - دوام خاص',
        'day' => 5,
        'working_days' => [0, 1, 2, 3, 4, 5],
        'should_work' => true
    ],
];

foreach ($workingDaysTests as $test) {
    $is_working_day = in_array($test['day'], $test['working_days'], true);
    $status = ($is_working_day === $test['should_work']) ? '✅ PASS' : '❌ FAIL';
    
    if ($is_working_day === $test['should_work']) {
        $passed++;
    } else {
        $failed++;
    }
    
    $day_names = ['الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];
    echo sprintf("  %s: %s\n", $status, $test['name']);
    echo sprintf("     اليوم: %s | أيام العمل: %s | النتيجة: %s\n\n",
        $day_names[$test['day']],
        implode(',', $test['working_days']),
        $is_working_day ? 'يوم عمل' : 'إجازة'
    );
}

// ═══════════════════════════════════════════════════════════════════════════════
// TEST SUMMARY
// ═══════════════════════════════════════════════════════════════════════════════

$total = $passed + $failed;
$percentage = $total > 0 ? round(($passed / $total) * 100, 1) : 0;

echo "═══════════════════════════════════════════════════════════════════════════════\n";
echo "                            ملخص نتائج الاختبار                               \n";
echo "                            Test Results Summary                               \n";
echo "═══════════════════════════════════════════════════════════════════════════════\n";
echo sprintf("\n  ✅ نجح: %d اختبار\n", $passed);
echo sprintf("  ❌ فشل: %d اختبار\n", $failed);
echo sprintf("  📊 النسبة: %.1f%%\n\n", $percentage);

if ($failed === 0) {
    echo "  🎉 جميع الاختبارات نجحت! منطق الحضور والانصراف يعمل بشكل صحيح.\n";
} else {
    echo "  ⚠️  يوجد بعض الاختبارات الفاشلة. يرجى مراجعة المنطق.\n";
}

echo "\n═══════════════════════════════════════════════════════════════════════════════\n";

// Return exit code based on test results
exit($failed > 0 ? 1 : 0);
